function [groupnum,group,separableFun,bestCandVal,result,G,innerFailCounter] = CC(fun,algorithm,cycle,groupnum,separableFun,group,needCapture,result,learnStage,innerFailCounter,outputInteval,contiFail)
%% the internal sub-optimizer for subcomponents
% Author: Wenxiang Chen,
% If you have any problem, please feel free to contact me: 
% Email: chenwx@mail.ustc.edu.cn; chenwx.ustc@gmail.com
%
% Last update: 5/10/2010

global FES1;
global FES2;
global fes;
global FES;
global bestCand;
global curVal;

global totalPop;

% for recording learning in last generation
global groupCR;
global groupF;

% record those groups'indices of updating inaccurate bestCand,for ingoring inaccurate merging two subcomponent
global inaccurateG;

%% ========== constant ==========
groupIndex = groupnum;
refresh = outputInteval; % the interval to output the bestVal to file trace
index  = group{groupIndex};
fbias=[];
fbias = [fbias zeros(1,21)];
D = length(index);LB = fun.LB; UB = fun.UB;
innerImprove = false;

%% setting for G and NP
if learnStage == true
    NP = size(totalPop{index},1);
else
    NP = size(totalPop{groupIndex},1);
end

if learnStage == true
    % setting of G for capturing stage
    G = 1;
elseif length(group)==1
    % if begin real optimization stage, then set the G to be inf
    G = inf;
else
    G = min(length(index)+5,500);
end

MAX_FES = NP*G+100;

if isempty(LB), LB = -UB; end
Achive_Rate= 1;

%% Initalize the parameter values of each algorithm
c = algorithm.c; p = algorithm.p;

if learnStage == true
    Fm = 0.50;
    CRm = 0.95;
else
    CRm = groupCR(groupnum); Fm = groupF(groupnum);
end

[F CR] = randFCR(NP, CRm, 0.1, Fm,  0.1);

if algorithm.Afactor > 0  % create an archive to store previously explored inferior solutions
    archive.NP = algorithm.Afactor * NP* Achive_Rate;    % the maximum size of the archive
    archive.pop = [];              % the solutions stored in the archive
    archive.funvalues = [];        % the function value of the archived solutions
end

%% ========== population initialization and evaluation ==========
g = 1;
g_restart=1;

fesCollab = repmat(bestCand,NP,1);
if learnStage == true
    fesCollab(:,index) = totalPop{index};
else
    fesCollab(:,index) = totalPop{groupIndex};
end
valParents = fun.objfun(fesCollab);
[preBest groupBestIndex]= min(valParents);
if learnStage == true
    bestCand(index) = totalPop{index}(groupBestIndex);
else
    bestCand(index) = totalPop{groupIndex}(groupBestIndex);
end
fes = fes +NP;
local_fes = 0;
popold = fesCollab;

%% ========================= iteration ==========================
while g <= G && local_fes < MAX_FES
    local_fes = local_fes + NP;
    fes=fes + NP;
    if local_fes > MAX_FES || fes > FES
        break;
    end
    [valBest indBest] = sort(valParents, 'ascend');     % valBest is the best fitness value after sorting
    valBest = min(valBest);
    pop = popold;          % the old population becomes the current population
    if g_restart > 1 && ~isempty(goodCR) && sum(goodF) > 0 && sum(CR_rec)>0      % If goodF and goodCR are empty, pause the update
        CRm = (1-c)*CRm+c*sum(CR_rec.*goodCR)/sum(CR_rec);
        Fm = (1-c)*Fm + c*sum(goodF.^2)/sum(goodF);     % Lehmer mean
    end
    
    % Generate CR according to a normal distribution with mean CRm, and std 0.1
    % Generate F according to a cauchy distribution with location parameter
    % Fm, and scale parameter 0.1
    [F CR] = randFCR(NP, CRm, 0.1, Fm,  0.1);
    
    if algorithm.Afactor == 0   % without archive (it is actually a special case of JADE with archive)
        popAll = pop;
        [r1 r2] = gnR1R2(NP,size(popAll,1));
    else                        % with archive
        popAll = [pop; archive.pop];
        [r1 r2] = gnR1R2(NP, size(popAll, 1));
    end
    
    % Find the p-best solutions
    pNP = max(round(p*NP), 2);              % choose at least two best solutions
    randindex = ceil(rand(1, NP) * pNP);    % select from [1, 2, 3, ..., pNP]
    randindex = max(1, randindex);          % to avoid the problem that rand = 0 and thus ceil(rand) = 0
    pbest = pop(indBest(randindex),:);      % randomly choose one of the top 100p% solutions
    
    %%  ============================== Mutation ==========================
    vi = pop;
    vi(:,index)= pop(:,index) + F(:,ones(1,length(index))) .* (pbest(:,index) - pop(:,index) + pop(r1',index) - popAll(r2',index));
    % if the problem is bounary constraint
    if fun.boundConstraint
        vi = boundConstraint(vi, pop, LB, UB);
    end
    
    %%  ==============================Crossover=========================
    mask = rand(NP,D) > CR(:, ones(1,D));         % mask is used to indicate which elements of ui comes from the parent
    rows = (1:NP)'; cols = floor(rand(NP,1)*D)+1;   % choose one position where the element of ui doesn't come from the parent
    jrand = sub2ind([NP D],rows,cols); mask(jrand) = false;
    ui = vi;
    tmp = ones(size(pop,1),size(pop,2));
    tmp = logical(tmp);
    tmp(:,index) = mask;
    ui(tmp) = pop(tmp);
    
    
    %% ============================== Selection =========================
    valOffspring = fun.objfun(ui);
    % I==1: the offspring is better;   I==2: the parent is better
    [valtemp I] = min([valOffspring, valParents], [], 2);
    eqIndex = valOffspring == valParents;
    I(eqIndex) = 0;
    popold = pop;
    if algorithm.Afactor > 0    % failed solutions are saved to the archive
        archive = updateArchive(archive, popold(I==1,:), valtemp(I==1));
    end
    popold(I==1,:) = ui(I==1,:);
    goodCR = CR(I==1);
    goodF = F(I==1);
    CR_rec = (valParents(I==1) - valOffspring(I==1));
    valParents = valtemp;
    if learnStage == true
        totalPop{index} = popold(:,index);
    else
        totalPop{groupIndex} = popold(:,index);
    end
    %%  ======================== Save and Print Results
    if rem(g,refresh)==0 ||g == 1 || g == G
        if fes < FES1
            result.bfv1 =[result.bfv1 valBest];
            result.bfv2 =[result.bfv2 valBest];
        elseif fes < FES2
            result.bfv2 =[result.bfv2 valBest];
        end
        result.bfv =[result.bfv valBest];     % best function value at this generation
        result.fes=[result.fes fes];
    end
    
    % before capturing,eliminate those represent precision problems which may cause incorrect capture
    if learnStage == true
        [inaccurateG,bestCand]=eliminateError(valParents,algorithm,popold,index,bestCand,inaccurateG,preBest,cycle,learnStage);
    end
    g = g + 1;
    g_restart=g_restart+1;
end
%% End of the optimization group
if learnStage == true
    totalPop{index} = popold(:,index);
else
    totalPop{groupIndex} = popold(:,index);
    [inaccurateG,bestCand]=eliminateError(valParents,algorithm,popold,index,bestCand,inaccurateG,preBest,cycle,learnStage);
end

curVal = valParents;
bestCandVal = min(valParents);
if learnStage == false
    groupCR(groupnum) = mean(CR);
    groupF(groupnum) = mean(F);
    innerImprove = true;
    if bestCandVal >=preBest
        innerImprove = false;
    end
    if innerImprove == false
        innerFailCounter(groupIndex) = innerFailCounter(groupIndex) + 1;
    else
        innerFailCounter(groupIndex) = 0;
    end
end
result.bfv  = result.bfv-fbias(fun.fname-48);
result.bfv1 = result.bfv1-fbias(fun.fname-48);
result.bfv2 = result.bfv2-fbias(fun.fname-48);
end