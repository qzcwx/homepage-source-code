function result = CCVIL(fun, algorithm,outputInteval)
%% The program for the CCVIL algorithm
% The details of CCVIL algorithm can be found in
% 
% Wenxiang Chen, Thomas Weise, Zhenyu Yang and Ke Tang. Large-Scale Global 
% Optimization using Cooperative Coevolution with Variable Interaction Learning. 
% In: Proceedings of the 11th International Conference on Parallel Problem
% Solving from Nature (PPSN'10), Krakow, Poland, 2010, pp.300-309. 
%
% Author: Wenxiang Chen,
% If you have any problem, please feel free to contact me: 
% Email: chenwx@mail.ustc.edu.cn; chenwx.ustc@gmail.com
%
% Last update: 5/10/2010

global fes;  % Global fitness
global initGroupSize;
global bestCand; %
% for population Dynamics Increasing
global totalPop;

% for recording learning in last generation
global groupCR;
global groupF;

% record those inaccurate bestCand,for ingoring inaccurate merging two
% subcomponent
global inaccurateG;

%% ========== initialize the result ==========
result.bfv = [];     % the best-so-far function value
result.bfv1= [];     % the best-so-far function value for FES1
result.bfv2= [];     % the best-so-far function value for FES2
result.fes =[];
result.Fm  = [];      % the mean of F at each generation
result.CRm = [];     % the mean of CR at each generation
result.group = [];
%% constant initialization
D = fun.D; NP = fun.NP; LB = fun.LB; UB = fun.UB; MAX_FES = fun.MAX_FES;

%% ========== population initialization and evaluation ==========
% to check whether D can be divisible by initGroupSize
if round(D/initGroupSize) ~= D/initGroupSize
    disp('ERROR: Dimension is undivisible by initGroupSize');
    pause;
end
bestCand = popInitialize(1,D,LB,UB,'Uniform');
groupAmount = D/initGroupSize;
totalPop = cell(1,groupAmount);
for tmp = 1:groupAmount
    totalPop{tmp} = popInitialize(NP, initGroupSize, LB, UB, 'Uniform');
end

%% random generate the group, and eliminate the bias of grouping
index = randperm(D);
index = sort(index,'ascend');
group = cell(1,groupAmount);
for i=1:length(group)
    group(i) = { index(1+(i-1)*initGroupSize : i*initGroupSize) };
end

% fes = NP;
fes = 0;
cycle = 0;
separableFun = true;
inaccurateG=[];
lastCycleIndex = 0;
oneDgroup = cell(1,D);
for tmp = 1:D
    oneDgroup{tmp} = tmp;
end
optimizeInit = false;
learnStage = true;% a indicator to record whether it is in learnStage, true = Yes; false = No;
innerFailCounter = zeros(1,groupAmount);
contiFail = zeros(1,groupAmount);
popIncreaseF = 1;
preCycleBest = inf;
restart = false;
bestBefRestart = inf;
while fes < MAX_FES
    %% iteration, for evolve the subcomponent of population group by group
    cycle = cycle + 1;
    fprintf('cycle = %g\n',cycle);
    groupAmount = length(group);
    if learnStage == false
        failCount = length(find(innerFailCounter>algorithm.failThreshold))
    end
    result.group = [result.group groupAmount];
    i=1;
    if cycle > algorithm.thredholdUp || (cycle > algorithm.thredholdLow && length(group) == D) || length(group) == 1
        learnStage = false;
    end
    
    if learnStage == true
        oneDgroup = myRandPerm(oneDgroup);
    end
    while 1
        % break out of the cycle loop according to the Stage(Learn or not?)
        if (learnStage == true && i >length(oneDgroup)) || (learnStage == false && i > length(group))
            break;
        end;
        if learnStage == true
            %% prepare for capture in each generation. This time even the cycle can be utilized, since we optimize the parameters one by one
            if i == 1
                % population reInitialization
                lastCycleIndex = 0;
                disp('Population ReInitialization');
                
                totalPop = cell(1,D/initGroupSize);
                for tmp = 1:D/initGroupSize
                    totalPop{tmp} = popInitialize(NP, initGroupSize, LB, UB, 'Uniform');
                end
                inaccurateG = [];
            end
            needCapture = length(group)~=1 && ((cycle<= algorithm.thredholdLow) ||(separableFun == false && cycle<= algorithm.thredholdUp)) && lastCycleIndex~=0;
        elseif optimizeInit == false
            needCapture = false;
            totalPop = cell(1,groupAmount);
            %% initialize the record groupCR and groupF
            groupCR = ones(1,groupAmount)*0.5;
            groupF = ones(1,groupAmount)*0.5;
            
            for tmp = 1:groupAmount
                index = group{tmp};                
                NP = length(index) + 10;
                totalPop{tmp} = popInitialize(NP, length(group{tmp}) , LB, UB, 'Uniform');
            end
            optimizeInit = true;        
        end
        %% evolve the subpop with JADE
        if learnStage == true % for learning stage
            if lastCycleIndex ~= 0
                isSameGroup = cSameGroup(oneDgroup{i},lastCycleIndex,group);
            end
            % to decide whether current dimesion are in the same group with last dimension
            if lastCycleIndex==0 || isSameGroup == false
                optimizeGroup = oneDgroup{i};
                %                 optimizeGroup
                
                [i,oneDgroup,separableFun,bestCandVal,result,G,innerFailCounter] = CC(fun,algorithm,cycle,i,separableFun,oneDgroup,needCapture,result,learnStage,innerFailCounter,outputInteval,contiFail);
            else % last parameter and current parameter are in the same group, don't need neither capture nor optimize
                needCapture = false;
            end
        else % for optimization stage. From now on, totalPop is related with groupIndex
            if innerFailCounter(i)<=algorithm.failThreshold
                [i,group,separableFun,bestCandVal,result,G,innerFailCounter] = CC(fun,algorithm,cycle,i,separableFun,group,needCapture,result,learnStage,innerFailCounter,outputInteval,contiFail);
                if restart == true
                    preCycleBest = bestCandVal
                    restart = false;
                end
            end
        end
        % begin capture
        if needCapture && (isempty(inaccurateG)||(~isempty(find(i==inaccurateG, 1)) && length(group)> length(inaccurateG)) || (isempty(find(i==inaccurateG, 1)) && length(group)> length(inaccurateG)+1))
            [fes,separableFun,bestCand,group,groupCR,groupF,totalPop,i,inaccurateG,mergeSuc] = captureInter(totalPop,group,i,fun,fes,bestCand,separableFun,bestCandVal,inaccurateG,groupCR,groupF,lastCycleIndex,oneDgroup);
        end
        % record last optimized real index
        if learnStage==true && (lastCycleIndex==0 || isSameGroup == false || mergeSuc==true)
            lastCycleIndex = optimizeGroup;
        end
        if fes > MAX_FES
            break;
        end
        i=i+1;
    end
    if learnStage == false
        improveRate = (preCycleBest-bestCandVal)/bestCandVal
        if ((0<=improveRate && improveRate < 10^-2)||isnan(improveRate)) && bestCandVal < bestBefRestart
            % trapped into a local optimum
            disp('Restart!');
            bestBefRestart = bestCandVal;
            restart = true;
            groupAmount = length(group);
            innerFailCounter = zeros(1,groupAmount);
            popIncreaseF = popIncreaseF * 3;
            for tmp = 1:groupAmount
                index = group{tmp};                
                NP = (length(index) + 10)*popIncreaseF;
                totalPop{tmp} = popInitialize(NP, length(group{tmp}) , LB, UB, 'Uniform');
                bestCand(index) = totalPop{tmp}(ceil(NP*rand),:);
            end
        end
    end
    preCycleBest = bestCandVal;
    if length(result.fes)~= length(result.bfv)
        disp('ERROR');
    end
    fprintf('Total FES = %g, GroupAmount = %g,  func = %g, BestVal = %.6e, NP = %d, G = %d\n\n',fes,length(group),fun.fname-48,bestCandVal,NP, G);
end