
function M = creatematrix(D);

M = eye(D);

for i = 2:D
   MR = MRot(1, i, D);
   M = M*MR;
end

for i = 2:(D-1)
   MR = MRot(i, D, D);
   M = M*MR;
end

function MR = MRot(i, j, D)

MR = eye(D);
alpha = (rand()-0.5) * pi * 0.5;

MR(i, i) = cos(alpha);
MR(j, j) = cos(alpha);
MR(i, j) = sin(alpha);
MR(j, i) = -sin(alpha);

