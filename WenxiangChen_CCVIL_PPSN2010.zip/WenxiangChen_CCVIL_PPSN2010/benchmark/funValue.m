function f=funValue(x,func_num)
global initial_flag
persistent fhd f_bias

% benchmark_func.m is the main function for 25 test functions, all minimize
% problems
% e.g. f=benchmark_func(x,func_num)
% x is the variable, f is the function value 
% func_num is the function num,

%       25 TEST FUCNTIONS
% 	    Unimodal Functions (5):
% 1.    Shifted Sphere Function 					                Bounds[-100,100]	f_bias=-450
% 2.	Shifted Schwefel's Problem 1.2				            	Bounds[-100,100]	f_bias=-450
% 3.	Shifted Rotated High Conditioned Elliptic Function			Bounds[-100,100]	f_bias=-450
% 4.	Shifted Schwefel's Problem 1.2 with Noise in Fitness 		Bounds[-100,100]	f_bias=-450
% 5.	Schwefel's  Problem 2.6 with Global Optimum on Bounds		Bounds[-100,100]	f_bias=-310
% 
% 	    Multimodal Functions (20):
% 	    Basic Functions (7):
% 6.	Shifted Rosenbrock's  Function					            Bounds[-100,100]	f_bias=390 
% 7.	Shifted Rotated Griewank's  Function without Bounds	        Initilization Range [0, 600]	f_bias=-180
% 8.	Shifted Rotated Ackley's  Function with Global Optimum on Bounds	Bounds[-32,32]	f_bias=-140
% 9.	Shifted Rastrigin's  Function 					            Bounds[-5,5]	    f_bias=-330
% 10.	Shifted Rotated Rastrigin's  Function 				        Bounds[-5,5]	    f_bias=-330
% 11.	Shifted Rotated Weierstrass Function 				        Bounds[-0.5,0.5]	f_bias=90
% 12.	Schwefel's  Problem 2.13					                Bounds[-100,100]	f_bias=-460 
% 	    Expanded Functions (2):
% 13.	Expanded Extended Griewank's  plus Rosenbrock's  Function (F8F2)	Bounds[-3,1]	f_bias=-130
% 14.	Expanded Rotated Extended Scaffe's  F6 				        Bounds[-100,100]	f_bias=-300
% 	    Hybrid Composition Functions (11):
% 15.	Hybrid Composition Function 1				                Bounds[-5,5]	    f_bias= 120 
% 16.	Rotated Hybrid Composition Function 1				        Bounds[-5,5]	    f_bias= 120
% 17.	Rotated Hybrid Composition Function 1 with Noise in Fitness		Bounds[-5,5]	f_bias= 120
% 18.	Rotated Hybrid Composition Function 2			        	Bounds[-5,5]	    f_bias=10 
% 19.	Rotated Hybrid Composition Function 2 with a Narrow Basin for the Global Optimum	Bounds[-5,5]]	f_bias=10 
% 20.	Rotated Hybrid Composition Function 2 with the Global Optimum on the Bounds		Bounds[-5,5]	f_bias=10
% 21.	Rotated Hybrid Composition Function 3						Bounds[-5,5]    	f_bias=360 
% 22.	Rotated Hybrid Composition Function 3 with High Condition Number Matrix		Bounds[-5,5]	f_bias=360
% 23.	Non-Continuous Rotated Hybrid Composition Function 3		Bounds[-5,5]    	f_bias=360 
% 24.	Rotated Hybrid Composition Function 4				        Bounds[-5,5]	    f_bias=260 
% 25.	Rotated Hybrid Composition Function 4 without Bounds	    Intilization Range[-2,5]	f_bias=260 
%
%J. J. Liang & P. N. Suganthan   2005.Feb 18

if initial_flag==0
    if func_num==1 fhd=str2func('sphere_func'); %[-100,100]
    % CEC2010 
    % Separable, D = 1000
    elseif (func_num ==  49) fhd = str2func('elliptic_shift_func');
    elseif (func_num ==  50) fhd = str2func('rastrigin_shift_func');
    elseif (func_num ==  51) fhd = str2func('ackley_shift_func');
    % Single-group m-nonseparable, D = 1000, m = 50
	elseif (func_num ==  52) fhd = str2func('elliptic_group1_shift_rot_func');
    elseif (func_num ==  53) fhd = str2func('rastrigin_group1_shift_rot_func');
    elseif (func_num ==  54) fhd = str2func('ackley_group1_shift_rot_func');
    elseif (func_num ==  55) fhd = str2func('schwefel_group1_shift_func');
    elseif (func_num ==  56) fhd = str2func('rosenbrock_group1_shift_func');
    % D/(2m)-group m-nonseparable, D = 1000, m = 50
	elseif (func_num ==  57) fhd = str2func('elliptic_group10_shift_rot_func');
    elseif (func_num ==  58) fhd = str2func('rastrigin_group10_shift_rot_func');
    elseif (func_num == 59) fhd = str2func('ackley_group10_shift_rot_func');
    elseif (func_num == 60) fhd = str2func('schwefel_group10_shift_func');
    elseif (func_num == 61) fhd = str2func('rosenbrock_group10_shift_func');
    % D/m-group m-nonseparable, D = 1000, m = 50
	elseif (func_num == 62) fhd = str2func('elliptic_group20_shift_rot_func');
    elseif (func_num == 63) fhd = str2func('rastrigin_group20_shift_rot_func');
    elseif (func_num == 64) fhd = str2func('ackley_group20_shift_rot_func');
    elseif (func_num == 65) fhd = str2func('schwefel_group20_shift_func');
    elseif (func_num == 66) fhd = str2func('rosenbrock_group20_shift_func');
    % Fully-nonseparable, D = 1000
	elseif (func_num == 67) fhd = str2func('schwefel_shift_func');
    elseif (func_num == 68) fhd = str2func('rosenbrock_shift_func');
    % simple sphere function
    elseif (func_num == 69) fhd = str2func('sphere_func');    
        
    elseif func_num==2 fhd=str2func('schwefel_102'); %[-100,100]
    elseif func_num==3 fhd=str2func('high_cond_elliptic_rot_func'); %[-100,100]
    elseif func_num==4 fhd=str2func('schwefel_102_noise_func'); %[-100,100]
    elseif func_num==5 fhd=str2func('schwefel_206'); %[no bound],initial[-100,100];
    elseif func_num==6 fhd=str2func('rosenbrock_func'); %[-100,100]
    elseif func_num==7 fhd=str2func('griewank_rot_func'); %[-600,600]
    elseif func_num==8 fhd=str2func('ackley_rot_func'); %[-32,32]
    elseif func_num==9 fhd=str2func('rastrigin_func'); %[-5,5]
    elseif func_num==10 fhd=str2func('rastrigin_rot_func'); %[-5,5]
    elseif func_num==11 fhd=str2func('weierstrass_rot'); %[-0.5,0.5]
    elseif func_num==12 fhd=str2func('schwefel_213'); %[-pi,pi]
    elseif func_num==13 fhd=str2func('EF8F2_func'); %[-3,1] 
    elseif func_num==14 fhd=str2func('E_ScafferF6_func'); %[-100,100]
    elseif func_num==15 fhd=str2func('hybrid_func1'); %[-5,5]
    elseif func_num==16 fhd=str2func('hybrid_rot_func1'); %[-5,5]
    elseif func_num==17 fhd=str2func('hybrid_rot_func1_noise'); %[-5,5]        
    elseif func_num==18 fhd=str2func('hybrid_rot_func2'); %[-5,5]    
    elseif func_num==19 fhd=str2func('hybrid_rot_func2_narrow'); %[-5,5]    
    elseif func_num==20 fhd=str2func('hybrid_rot_func2_onbound'); %[-5,5]  
    elseif func_num==21 fhd=str2func('hybrid_rot_func3'); %[-5,5]    
    elseif func_num==22 fhd=str2func('hybrid_rot_func3_highcond'); %[-5,5]  
    elseif func_num==23 fhd=str2func('hybrid_rot_func3_noncont'); %[-5,5]   
    elseif func_num==24 fhd=str2func('hybrid_rot_func4'); %[-5,5]  
    elseif func_num==25 fhd=str2func('hybrid_rot_func4'); %[-5,5]  
    elseif func_num==26 fhd=str2func('fepf01');
    elseif func_num==27 fhd=str2func('fepf02');
    elseif func_num==28 fhd=str2func('fepf03');
    elseif func_num==29 fhd=str2func('fepf04');
    elseif func_num==30 fhd=str2func('fepf05');
    elseif func_num==31 fhd=str2func('fepf06');
    elseif func_num==32 fhd=str2func('fepf07');
    elseif func_num==33 fhd=str2func('fepf08');
    elseif func_num==34 fhd=str2func('fepf09');
    elseif func_num==35 fhd=str2func('fepf10');
    elseif func_num==36 fhd=str2func('fepf11');
    elseif func_num==37 fhd=str2func('fepf12');
    elseif func_num==38 fhd=str2func('fepf13');
    elseif func_num==39 fhd=str2func('fepf14');
    elseif func_num==40 fhd=str2func('fepf15');
    elseif func_num==41 fhd=str2func('fepf16');
    elseif func_num==42 fhd=str2func('fepf17');
    elseif func_num==43 fhd=str2func('fepf18');
    elseif func_num==44 fhd=str2func('fepf19');
    elseif func_num==45 fhd=str2func('fepf20');
    elseif func_num==46 fhd=str2func('fepf21');
    elseif func_num==47 fhd=str2func('fepf22');
    elseif func_num==48 fhd=str2func('fepf23');
    end
  
    load fbias_data;
    f_bias = [f_bias zeros(1,44)];
    jrandflag = 0;
    if (jrandflag == 1)
        jrand = Randomizer(func_num);
    end
end


   f=feval(fhd,x);



%======================== CEC 2010 ===============================

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Sphere Function 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = sphere_func(x)

fit = sum(x.*x, 2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Elliptic Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = elliptic_func(x)

[ps, D] = size(x);
a = 1e+6;
fit = 0;
for i = 1:D
   fit = fit+a.^((i-1)/(D-1)).*x(:,i).^2;
end
% disp('1');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rotated Elliptic Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = elliptic_rot_func(x, M)

x = x*M;
fit = elliptic_func(x);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Schwefel's Problem 1.2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = schwefel_func(x)

[ps D] = size(x);
fit = 0;
for i = 1:D
	fit = fit + sum(x(:,1:i),2).^2;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rosenbrock's Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rosenbrock_func(x)

[ps D] = size(x);
fit = sum(100.*(x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rastrigin's Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rastrigin_func(x)

fit = sum(x.*x-10*cos(2*pi*x)+10, 2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rotated Rastrigin's Fucntion 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rastrigin_rot_func(x, M)

x = x*M;
fit = rastrigin_func(x);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ackley's Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = ackley_func(x)

[ps, D] = size(x);
fit = sum(x.^2,2);
fit = 20-20.*exp(-0.2.*sqrt(fit./D))-exp(sum(cos(2.*pi.*x),2)./D)+exp(1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Rotated Ackley's Function 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = ackley_rot_func(x, M)

x = x*M;
fit = ackley_func(x);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F1: Shifted Elliptic Function
% D = 1000
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = elliptic_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o

[ps D] = size(x);
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
		save 'datafiles/f01_o.mat' o;
    else
		load 'datafiles/f01_o.mat';
		o = o(1:D);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = elliptic_func(x);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F2: Shifted Rastrigin's Function
% D = 1000
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rastrigin_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o

[ps D] = size(x);
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
		save 'datafiles/f02_o.mat' o;
    else
		load 'datafiles/f02_o.mat';
		o = o(1:D);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = rastrigin_func(x);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F3: Shifted Ackley's Function
% D = 1000
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = ackley_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o

[ps D] = size(x);
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
		save 'datafiles/f03_o.mat' o;
    else
		load 'datafiles/f03_o.mat' o;
		o = o(1:D);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = ackley_func(x);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F4: Single Group Shifted and Rotated Elliptic Function
% D = 1000, m = 50
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = elliptic_group1_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
        M = jrand.createRotMatrix(m);
		save 'datafiles/f04_opm.mat' o p M;
    else
		load 'datafiles/f04_opm.mat';
    end
    if (D ~= 1000)
        disp('F4 error: only support D = 1000 now');
        exit(4);
    end
	initial_flag = 1;
end

a = 1e+6;
x = x-repmat(o,ps,1);
fit = a*elliptic_rot_func(x(:,p(1:m)), M) + elliptic_func(x(:,p((m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F5: Single Group Shifted and Rotated Rastrigin's Function
% D = 1000, m = 50
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rastrigin_group1_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f05_opm.mat' o p M;
    else
		load 'datafiles/f05_opm.mat';
    end
    if (D ~= 1000)
        disp('F5 error: only support D = 1000 now');
        exit(5);
    end
	initial_flag = 1;
end

a = 1e+6;
x = x-repmat(o,ps,1);
fit = a*rastrigin_rot_func(x(:,p(1:m)), M) + rastrigin_func(x(:,p((m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F6: Single Group Shifted and Rotated Ackley's Function
% D = 1000, m = 50
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = ackley_group1_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f06_opm.mat' o p M;
    else
		load 'datafiles/f06_opm.mat';
    end
    if (D ~= 1000)
        disp('F6 error: only support D = 1000 now');
        exit(6);
    end
	initial_flag = 1;
end

a = 1e+6;
x = x-repmat(o,ps,1);
fit = a*ackley_rot_func(x(:,p(1:m)), M) + ackley_func(x(:,p((m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F7: Single Group Shifted Schwefel's Problem 1.2
% D = 1000, m = 50
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = schwefel_group1_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p

[ps D] = size(x);
m = 50;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		save 'datafiles/f07_op.mat' o p;
    else
		load 'datafiles/f07_op.mat';
    end
    if (D ~= 1000)
        disp('F7 error: only support D = 1000 now');
        exit(7);
    end
	initial_flag = 1;
end

a = 1e+6;
x = x-repmat(o,ps,1);
fit = a*schwefel_func(x(:,p(1:m))) + sphere_func(x(:,p((m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F8: Single Group Shifted Rosenbrock's Function
% D = 1000, m = 50
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rosenbrock_group1_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p

[ps D] = size(x);
m = 50;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub-1);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		save 'datafiles/f08_op.mat' o p;
    else
		load 'datafiles/f08_op.mat';
    end
    if (D ~= 1000)
        disp('F8 error: only support D = 1000 now');
        exit(8);
    end
	initial_flag = 1;
end

a = 1e+6;
x = x-repmat(o,ps,1);
fit = a*rosenbrock_func(x(:,p(1:m))) + sphere_func(x(:,p((m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F9: D/(2m)-group Shifted and Rotated Elliptic Function
% D = 1000, m = 50, D/(2m) = 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = elliptic_group10_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
G = D/m/2;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f09_opm.mat' o p M;
    else
		load 'datafiles/f09_opm.mat';
    end
    if (D ~= 1000)
        disp('F9 error: only support D = 1000 now');
        exit(9);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + elliptic_rot_func(x(:,p(index)), M);
end
fit = fit + elliptic_func(x(:,p((G*m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F10: D/(2m)-group Shifted and Rotated Rastrigin's Function
% D = 1000, m = 50, D/(2m) = 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rastrigin_group10_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
G = D/m/2;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f10_opm.mat' o p M;
    else
		load 'datafiles/f10_opm.mat';
    end
    if (D ~= 1000)
        disp('F10 error: only support D = 1000 now');
        exit(10);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + rastrigin_rot_func(x(:,p(index)), M);
end
fit = fit + rastrigin_func(x(:,p((G*m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F11: D/(2m)-group Shifted and Rotated Ackley's Function
% D = 1000, m = 50, D/(2m) = 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = ackley_group10_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
G = D/m/2;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f11_opm.mat' o p M;
    else
		load 'datafiles/f11_opm.mat';
    end
    if (D ~= 1000)
        disp('F11 error: only support D = 1000 now');
        exit(11);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + ackley_rot_func(x(:,p(index)), M);
end
fit = fit + ackley_func(x(:,p((G*m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F12: D/(2m)-group Shifted Schwefel's Problem 1.2
% D = 1000, m = 50, D/(2m) = 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = schwefel_group10_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p

[ps D] = size(x);
m = 50;
G = D/m/2;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		save 'datafiles/f12_op.mat' o p;
    else
		load 'datafiles/f12_op.mat';
    end
    if (D ~= 1000)
        disp('F12 error: only support D = 1000 now');
        exit(12);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + schwefel_func(x(:,p(index)));
end
fit = fit + sphere_func(x(:,p((G*m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F13: D/(2m)-group Shifted Rosenbrock's Function
% D = 1000, m = 50, D/(2m) = 10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rosenbrock_group10_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p

[ps D] = size(x);
m = 50;
G = D/m/2;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub-1);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		save 'datafiles/f13_op.mat' o p;
    else
		load 'datafiles/f13_op.mat';
    end
    if (D ~= 1000)
        disp('F13 error: only support D = 1000 now');
        exit(13);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + rosenbrock_func(x(:,p(index)));
end
fit = fit + sphere_func(x(:,p((G*m+1):end)));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F14: D/m-group Shifted and Rotated Elliptic Function
% D = 1000, m = 50, D/m = 20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = elliptic_group20_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
G = D/m;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f14_opm.mat' o p M;
    else
		load 'datafiles/f14_opm.mat';
    end
    if (D ~= 1000)
        disp('F14 error: only support D = 1000 now');
        exit(14);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + elliptic_rot_func(x(:,p(index)), M);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F15: D/m-group Shifted and Rotated Rastrigin's Function
% D = 1000, m = 50, D/m = 20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rastrigin_group20_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
G = D/m;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f15_opm.mat' o p M;
    else
		load 'datafiles/f15_opm.mat';
    end
    if (D ~= 1000)
        disp('F15 error: only support D = 1000 now');
        exit(15);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + rastrigin_rot_func(x(:,p(index)), M);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F16: D/m-group Shifted and Rotated Ackley's Function
% D = 1000, m = 50, D/m = 20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = ackley_group20_shift_rot_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p M

[ps D] = size(x);
m = 50;
G = D/m;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		M = jrand.createRotMatrix(m);
		save 'datafiles/f16_opm.mat' o p M;
    else
		load 'datafiles/f16_opm.mat';
    end
    if (D ~= 1000)
        disp('F16 error: only support D = 1000 now');
        exit(16);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + ackley_rot_func(x(:,p(index)), M);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F17: D/m-group Shifted Schwefel's Problem 1.2
% D = 1000, m = 50, D/m = 20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = schwefel_group20_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p

[ps D] = size(x);
m = 50;
G = D/m;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		save 'datafiles/f17_op.mat' o p;
    else
		load 'datafiles/f17_op.mat';
    end
    if (D ~= 1000)
        disp('F17 error: only support D = 1000 now');
        exit(17);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + schwefel_func(x(:,p(index)));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F18: D/m-group Shifted Rosenbrock's Function
% D = 1000, m = 50, D/m = 20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rosenbrock_group20_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o p

[ps D] = size(x);
m = 50;
G = D/m;
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub-1);
        o = o';
        p = jrand.createPermVector(D);
        p = p'+1;
		save 'datafiles/f18_op.mat' o p;
    else
		load 'datafiles/f18_op.mat';
    end
    if (D ~= 1000)
        disp('F18 error: only support D = 1000 now');
        exit(18);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = 0;
for k = 1:G
    index = ((k-1)*m+1):(k*m);
    fit = fit + rosenbrock_func(x(:,p(index)));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F19: Shifted Schwefel's Problem 1.2
% D = 1000
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = schwefel_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o

[ps D] = size(x);
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub);
        o = o';
		save 'datafiles/f19_o.mat' o;
    else
		load 'datafiles/f19_o.mat';
    end
    if (D ~= 1000)
        disp('F19 error: only support D = 1000 now');
        exit(19);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = schwefel_func(x);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F20: Shifted Rosenbrock's Function
% D = 1000
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fit = rosenbrock_shift_func(x)
global initial_flag jrandflag jrand lb ub
persistent o

[ps D] = size(x);
if (initial_flag == 0)
    if (jrandflag == 1)
        o = jrand.createShiftVector(D, lb, ub-1);
        o = o';
		save 'datafiles/f20_o.mat' o;
    else
		load 'datafiles/f20_o.mat';
    end
    if (D ~= 1000)
        disp('F20 error: only support D = 1000 now');
        exit(20);
    end
	initial_flag = 1;
end

x = x-repmat(o,ps,1);
fit = rosenbrock_func(x);


%%%%% end of file %%%%%


% function value = funValue(pop, fname)
% 
% [NP D] = size(pop);
% switch fname
%     case 'f1:Spherical'       %x(1)^2 + x(2)^2 + ... + x(D)^2;
%         value = sum(pop.^2,2);          
%     case'f2:Schwefel2.22'
%         % \sum  |xi| + \prod |xi|
%         % f(x*) = 0
%         value = sum(abs(pop),2) + prod(abs(pop),2);
%     case'f3:Schwefel1.2'    % (x(1))^2 + (x(1)+x(2))^2 + (x(1)+x(2)+x(3))^2 + ...  
%         value = sum(cumsum(pop,2).^2,2); 
%     case'f4:Schwefel2.21'
%         % max{|xi|}
%         % f(x*) = 0
%         value = max(abs(pop),[],2);
%     case'f5:Rosenbrock'       %  [100*(x1^2-x2)^2 + (x1-1)^2]  + [100*(x2^2-x3)^2 + (x2-1)^2] + ...
%         value = sum(100*(pop(:,1:end-1).^2 - pop(:,2:end)).^2 + (pop(:,1:end-1)-1).^2, 2);
%     case'f6:StepFunction'
%         %   \sum  (floor(xi+0.5))^2
%         %   f(x*) = 0
%         value = sum(floor(pop+0.5).^2,2);
%     case'f7:NoisyQuartic'
%         %   \sum  i*xi^4+rand
%         %   f(x*) = 0
%         value = pop.^4 * [1:D]' + rand(NP,1);
%     case'f8:Schwefel2.26'
%         % \sum  xi * sin(sqrt(|xi|))
%         value = -sum(pop.*sin(sqrt(abs(pop))), 2) + D*418.9828872724338;
%     case'f9:Rastrigin'
%         %   \sum x(i)^2- 10*cos(2*pi*x(i))^2 + 10
%         %   Bounds: [-5.12, 5.12]^D
%         %   load(sprintf('rastrigin_M_D%d.mat',D));
%         %   pop = (pop - o(ones(NP,1), 1:D)) * M;
% 
%         value = sum(pop.^2 - 10*cos(2*pi*pop) + 10, 2);
%     case'f10:Ackley'
%         %   -20*exp( -0.2*sqrt((x1^2+x2^2 + xD^2)/D)) - exp((cos(2pi*x1) + ... + cos(2*pi*xD))/D) + 20 + e
%         %   x* = 0, f(x*) = 0,  epsilon = 1e-6,  Bounds: [-30, 30]^D
%         value = -20 * exp(-0.2*sqrt( mean(pop.^2,2))) - exp( mean(cos(2*pi*pop), 2)) + 20 + exp(1);
%     case'f11:Griewank'
%         % 1/4000 * (x(1)^2 + ... + x(D)^2)  - \prod cos(xi/sqrt(i))  + 1
%         % x* = 0; f(x*)=0; Bounds: [-600, 600]
%         value = 1/4000 * sum(pop.^2,2) - prod(cos(pop./repmat(sqrt([1:D]),NP,1)),2) + 1;
%     case'f12:PenalizedFun1'
%         % 
%         popy = 1+(pop+1)/4;
%         value = pi/D*( 10*sin(pi*popy(:,1)).^2  + (popy(:,end)-1).^2 )...
%              + pi/D*sum((popy(:,1:end-1)-1).^2.*(1+10*sin(pi*popy(:,2:end)).^2), 2) ...
%              + sum(u(pop,10,100,4),2);
%     case'f13:PenalizedFun2'
%         % 
%         value = 0.1*(sin(3*pi*pop(:,1)).^2 + (pop(:,end)-1).^2.*(1+sin(2*pi*pop(:,end)).^2)) ...
%              + 0.1*sum((pop(:,1:end-1)-1).^2.*(1+sin(3*pi*pop(:,2:end)).^2), 2) ...
%              + sum(u(pop,5,100,4),2);
%     otherwise
%         error('Please first define the function %s.', fname);
% end

function value = u(x, a, k, m) 

value = k*(abs(x)-a).^m;
pos = abs(x)<a;
value(pos) = 0;
