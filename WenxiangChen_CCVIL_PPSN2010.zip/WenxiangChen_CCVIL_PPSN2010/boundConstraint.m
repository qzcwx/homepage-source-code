function vi = boundConstraint (vi, pop, LB, UB)
% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang (zhangj14@rpi.edu)


if isempty(LB), LB = -UB; end
[NP D] = size(pop);  % the population size and the problem's dimension

%% check the lower bound
if length(LB)==1
    pos = vi < LB;      vi(pos) = (pop(pos) + LB)/2;
else
    xLB = repmat(LB, NP, 1);
    pos = vi < xLB; 	vi(pos) = (pop(pos) + xLB(pos))/2;
end

%% check the upper bound
if length(UB)==1
    pos = vi > UB;      vi(pos) = (pop(pos) + UB)/2;
else
    xUB = repmat(UB, NP, 1);
    pos = vi > xUB; 	vi(pos) = (pop(pos) + xUB(pos))/2;
end