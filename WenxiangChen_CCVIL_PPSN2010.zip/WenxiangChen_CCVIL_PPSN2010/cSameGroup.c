// cSameGroup.c
// A implementation of matlab version sameGroup for speedup the programme
// Author: Wenxiang Chen, Email: chenwx@mail.ustc.edu.cn
// ***************************************************************************************************
// USEAGE: [same,groupi,groupj]=sameGroup(i,j,group)
//        where i,j is the real index of two dimension
//        return groupi,groupj as the group Index, and "same" indicates where they are in the same group
// ***************************************************************************************************
// Version: 1.0, 2010-3-27

#include "mex.h"
#include <string.h>
#include <stdio.h>

void mexFunction(int nlhs, mxArray *plhs[], 
        int nrhs, const mxArray *prhs[]){
    const mxArray *cell_element_ptr;
    char* c_array;
    mwIndex i,j;
    mwSize total_num_of_cells, buflen;
    int status;
    int indexi,indexj;
    double *groupi,*groupj,*same,*pr;
    int len;
    char match;
    
    if (nrhs!=3){
        mexErrMsgTxt("USAGE: b=errHandle(a)\n");
        return;
    }
    // NOTE: Here, we get a pointer, it may cause a error
    // Preparation for output parameters
    plhs[0]= mxCreateDoubleScalar(1);
    plhs[1]= mxCreateDoubleScalar(0);
    plhs[2]= mxCreateDoubleScalar(0);
    same = mxGetPr(plhs[0]);
    groupi = mxGetPr(plhs[1]);
    groupj = mxGetPr(plhs[2]);        
    
    // Recieve input parameters
    indexi = mxGetScalar(prhs[0]);
// 	mexPrintf("indexi=%d\n",indexi);
    indexj = mxGetScalar(prhs[1]);
//     mexPrintf("indexj=%d\n",indexj);
	total_num_of_cells = mxGetNumberOfElements(prhs[2]);
    
    // Find the group index for input index i
    for(i=0;i<total_num_of_cells;i++){
		// go over all cells
        cell_element_ptr = mxGetCell(prhs[2], i);
		len =mxGetN(cell_element_ptr);
// 		mexPrintf("\nLen of cell array is %d\n",len);
		if (cell_element_ptr==NULL)
		{
			mexPrintf("Empty Cell!");
		}
		else
		{	// search in a single cell array
			match=0;
            pr = mxGetPr(cell_element_ptr);
			for (j=0;j<len;j++)
			{
//                 mexPrintf("\t%f",pr[j]);
				if (pr[j] == indexi)
				{
					*groupi = (double)(i+1);
					match=1;
// 					mexPrintf("\nGroupI=%d\n",i+1);
					break;
				}
			}
			if (match==1)
				break;
		}
    }
    
    // Find the group index for input index j
	for(i=0;i<total_num_of_cells;i++){
		// go over all cells
		cell_element_ptr = mxGetCell(prhs[2], i);
		len =mxGetN(cell_element_ptr);
// 		mexPrintf("\nLen of cell array is %d\n",len);
		if (cell_element_ptr==NULL)
		{
// 			mexPrintf("Empty Cell!");
		}
		else
		{	// search in a single cell array
			match=0;
            pr = mxGetPr(cell_element_ptr);
			for (j=0;j<len;j++)
			{				
// 				mexPrintf("\t%f",pr[j]);
                if (pr[j] == indexj)
				{
					*groupj = (double)(i+1);
					match=1;
// 					mexPrintf("\nGroupI=%d\n",i+1);
					break;
				}
			}
			if (match==1)
				break;
		}
	}
    
    // To judge whethere the two subcomponents are in the same group
    if (*groupi == *groupj)
    {
//         printf("\nSame Group!\n");
       *same = (double)1;
    }
    else
	{
//         printf("\nDifferent Group!\n");
		*same = (double)0;
	}
    
//     mexPrintf("Success\n");
}
