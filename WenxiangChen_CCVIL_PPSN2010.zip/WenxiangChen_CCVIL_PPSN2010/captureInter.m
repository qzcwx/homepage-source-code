function [fes,separableFun,bestCand,group,groupCR,groupF,totalPop,groupIndex,inaccurateG,mergeSuc]=captureInter(totalPop,group,groupIndex,fun,fes,bestCand,separableFun,bestCandVal,inaccurateG,groupCR,groupF,lastCycleIndex,oneDgroup)
%% capture between subcomponents procedure
% NOTE: totalPop here correspond to the real index
% Author: Wenxiang Chen,
% If you have any problem, please feel free to contact me: 
% Email: chenwx@mail.ustc.edu.cn; chenwx.ustc@gmail.com
%
% Last update: 5/10/2010

mergeSuc = false;
index = oneDgroup{groupIndex};
groupAmount = length(group);

% get randj directly from last successfully optimized cycle
randj = lastCycleIndex;

if ~isempty(inaccurateG)
    if sum(randj==inaccurateG)>0
        disp('WARNING: Meet An inaccurate Group!! Give up Capturing');
        return;
    end
end

%% generate randIndiv
randIndiv = bestCand;
randi = ceil(rand*size(totalPop{randj},1));
counter = 1;
while totalPop{randj}(randi,:) == bestCand(randj)
    randi = ceil(rand*size(totalPop{randj},1));
    counter = counter + 1;
    if counter>10000
        disp('ERROR : More than 10000 times to generate RANDi');
        pause;
        break;
    end
end
randIndiv(randj)=totalPop{randj}(randi,:);
randVal = fun.objfun(randIndiv);
bestCandVal = fun.objfun(bestCand);
fes = fes + 1;
% find the group index for real index
[tmp,groupIndexI,groupIndexJ] = cSameGroup(index,randj,group);
if  bestCandVal > randVal
    fprintf('MERGE Group %d & Group %d\n',index, randj);    
    [group,totalPop] = myunion(groupIndexI,groupIndexJ,group,totalPop,bestCand);   
    mergeSuc = true;
    separableFun = false;

end

end