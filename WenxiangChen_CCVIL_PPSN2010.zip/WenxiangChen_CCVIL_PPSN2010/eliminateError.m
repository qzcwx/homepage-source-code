function  [inaccurateG,bestCand]=eliminateError(valParents,algorithm,popold,index,bestCand,inaccurateG,preBest,cycle,learnStage)
%% find out same the individuals (if any) with fitness value and dinstinct gene

[bestCollab  groupBestIndex]= min(valParents);
if learnStage == true
    uniqueBest = find(valParents == bestCollab);
    Allequal = true;
    if length(uniqueBest)~=1 && cycle <= algorithm.thredholdUp
        gene = popold(groupBestIndex,index);
        for tmp = 2:length(uniqueBest)
            if gene~=popold(uniqueBest(tmp),index)
                Allequal = false;
                break;
            end
        end
        if Allequal == false
            % the refresh step here may be inaccurate
            bestCand(index) = popold(uniqueBest(ceil(rand*length(uniqueBest))),index);
            toAdd = inaccurateG == index;
            if isempty(toAdd)
                toAdd = 0;
            end
            if toAdd==0
                inaccurateG = [inaccurateG index];
                inaccurateG = sort(inaccurateG,'ascend');
            end
        end
    end
    if Allequal == true
        bestCand(index) = popold(groupBestIndex,index);
        toDel = inaccurateG==index;
        inaccurateG(toDel) = [];
    end
else
    bestCand(index) = popold(groupBestIndex,index);
end