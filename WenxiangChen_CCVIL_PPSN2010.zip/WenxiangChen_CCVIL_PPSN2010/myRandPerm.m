function [group,groupCR,groupF] = myRandPerm(group,groupCR,groupF)
groupAmount = length(group);
randS = randperm(groupAmount);
seq = sort(randS,'ascend');
group(seq) = group(randS);
end