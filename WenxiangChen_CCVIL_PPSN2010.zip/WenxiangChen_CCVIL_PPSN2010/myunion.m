function [group,totalPop] = myunion(i,j,group,totalPop,bestCand)
%% union group{i} and group{j} to a united group{i}, and group{j} has destroy since then
% Author: Wenxiang Chen,
% If you have any problem, please feel free to contact me: 
% Email: chenwx@mail.ustc.edu.cn; chenwx.ustc@gmail.com
%
% Last update: 5/10/2010
group{i}=union(group{i},group{j});
group(j) = [];
end