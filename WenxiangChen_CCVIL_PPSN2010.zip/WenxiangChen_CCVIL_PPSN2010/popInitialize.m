function pop = popInitialize(NP, D, LB, UB, strategy)
% popInitialize randomly generates NP D-dimensional vectors  
%
% Inputs:
% NP: the number of vectors to be generated
% D:  the dimension of the vector
% strategy: Uniform  -- uniform distribution
%           Gaussian -- Gaussian distribution
%           SLHD     -- Symmetric Latin Hypercube Design
% LB, UB:   In case of "Uniform", these are the lower and upper bounds 
%           In case of "Gaussian", (UB+LB)/2 is the mean and (UB-LB)/2 is std
% fa: 
% ind:
% Outputs:
% pop: a matrix of size NP*D  -- each row is a vector of length D
%
% Version: 1.0   Date: 03/15/2007
% Written by Jingqiao Zhang (zhangj14@rpi.edu)

if length(UB)==1, UB = UB*ones(1,D);end
if isempty(LB), LB = -UB; end
if length(LB)==1, LB = LB*ones(1,D);end

radBound = (UB - LB)/2;                          % the radius of the range
cenBound = (UB + LB)/2;  			 % the center of the range

if strcmp(strategy, 'Uniform')
    pop = repmat(radBound, NP,1) .*  (2*rand(NP,D)-1);
    pop = repmat(cenBound, NP,1) + pop;
elseif strcmp(strategy, 'Gaussian')
    pop = repmat(radBound, NP,1) .* randn(NP,D); %sigma = radBound
    pop = repmat(cenBound,NP,1) + pop;
end 

