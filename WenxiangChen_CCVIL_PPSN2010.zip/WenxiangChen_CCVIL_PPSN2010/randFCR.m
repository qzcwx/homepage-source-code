function [F CR] = randFCR(NP, CRm, CRsigma, Fm,  Fsigma)
% this function generate CR according to a normal distribution with mean "CRm" and sigma "CRsigma"
%           If CR > 1, set CR = 1. If CR < 0, set CR = 0.
% this function generate F  according to a cauchy distribution with location parameter "Fm" and scale parameter "Fsigma"
%           If F <= 0 || F > 1, regenrate F.
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang (zhangj14@rpi.edu)

%% generate CR
CR = CRm + CRsigma * randn(NP, 1);
CR = min(1, max(0, CR));                % truncated to [0 1]


%% generate F
F = randCauchy(NP, 1, Fm, Fsigma);
F = min(1, F);                          % truncation

% we don't want F = 0. So, if F<=0, we regenerate F (instead of trucating it to 0)
pos1 = find(F<=0);
pos2 = find(F>=1);
while ~ isempty(pos1) || ~isempty(pos2)
    F(pos1) = randCauchy(length(pos1), 1, Fm, Fsigma);
    F(pos2) = randCauchy(length(pos2), 1, Fm, Fsigma);
    F = min(1, F);                      % truncation
    pos1 = find(F<=0);
    pos2 = find(F>=1);
end

if ~isempty(find(F>=1, 1))
    disp('ERROR: F = 1');
    pause;
end

% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
function result = randCauchy(m, n, mu, delta)

% http://en.wikipedia.org/wiki/Cauchy_distribution
result = mu + delta*tan(pi*( rand(m,n) - 0.5 ));
