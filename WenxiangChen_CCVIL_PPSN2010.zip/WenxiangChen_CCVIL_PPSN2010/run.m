%% The program for the CCVIL algorithm
% The details of CCVIL algorithm can be found in
% 
% Wenxiang Chen, Thomas Weise, Zhenyu Yang and Ke Tang. Large-Scale Global 
% Optimization using Cooperative Coevolution with Variable Interaction Learning. 
% In: Proceedings of the 11th International Conference on Parallel Problem
% Solving from Nature (PPSN'10), Krakow, Poland, 2010, pp.300-309. 
%
% Author: Wenxiang Chen,
% If you have any problem, please feel free to contact me: 
% Email: chenwx@mail.ustc.edu.cn; chenwx.ustc@gmail.com
% 
% Last update: 5/10/2010

clc;
clear;

%% Compile two required C source files that the process within them is
% compuationally expensive, so that the whole Matlab program wouldn't run
% too slow
mex cSameGroup.c;
mex schwefel.c

% for the benchmark functions initialization
global initial_flag;

% the intial group size of Cooperative Coevolution
global initGroupSize;

% dimension of benchmark function, i.e., the amount of decision variables
global DIMENSION;

% fitness evaluation limitation for the entire algorithm process
global FES; 

% To meet the display requirement by CEC'2010 Specical Session on LSGO, here are
% two checkpoint
global FES1;
global FES2;

% record current fitness evaluatoin that algorithm have consumed
global fes;

% include the path of the directory of the "benckmark function set"
addpath('benchmark');

%% parameters configuration
DIMENSION=1000;

% the ID of benchmark functions to be tested in the experiment
funToRun=[1,7];

% the amount of independent run for 
runs = 25;

% In learning stage, the less the population size is, the better CCVIL will
% perform
NP=3;

% for initialization, CCVIL treats each decision variable as an independent
% group
initGroupSize = 1;


FES = 3e+6;
FES1 = 1.2e+5;
FES2 = 6.0e+5;

% output interval (i.e., output the results every generations)
outputInteval = 10; 

numOfFun=size(funToRun,2);
thresholdUp = min(round(FES*0.6/(DIMENSION*((1+1)*(3)+1))), 800);
algorithm = struct('name', 'CCVIL', 'c', 1/10, 'p', 0.05, 'Afactor', 1,'thredholdLow', 10 ,'thredholdUp',thresholdUp,'failThreshold',5);

%% the functions to be optimized (the function is defined in "funValue")
% fname: the name of the function (defined by user)
% D: the problem's dimension
% G: the total number of generations
% UB: upper bound  -- a scalar or a 1-by-D row vector.
% LB: lower bound  -- a scalar or a 1-by-D row vector. If it is empty, we set LB = -UB.
% boundConstraint
%           = 0: the LB and UB is ONLY used to creat the inital population
%           = 1: the LB and UB also define the search space.

% for Large Scale Optimization Problem CEC2010

funs(1) = struct('fname',49,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F1:
funs(2) = struct('fname',50,	'UB',  5, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	    % CEC2010 F2:
funs(3) = struct('fname',51,	'UB',  32, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	    % CEC2010 F3:
funs(4) = struct('fname',52,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F4:
funs(5) = struct('fname',53,	'UB',  5, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);       	% CEC2010 F5:
funs(6) = struct('fname',54,	'UB',  32, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);       	% CEC2010 F6:
funs(7) = struct('fname',55,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F7:
funs(8) = struct('fname',56,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F8:
funs(9) = struct('fname',57,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F9:
funs(10) = struct('fname',58,	'UB',  5, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);           % CEC2010 F10:
funs(11) = struct('fname',59,	'UB',  32, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);      	% CEC2010 F11:
funs(12) = struct('fname',60,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F12:
funs(13) = struct('fname',61,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F13:
funs(14) = struct('fname',62,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F14:
funs(15) = struct('fname',63,	'UB',  5, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	    % CEC2010 F15:
funs(16) = struct('fname',64,	'UB',  32, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);      	% CEC2010 F16:
funs(17) = struct('fname',65,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F17:
funs(18) = struct('fname',66,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F18:
funs(19) = struct('fname',67,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F19:
funs(20) = struct('fname',68,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% CEC2010 F20:

%% For simple test
funs(21) = struct('fname',69,	'UB',  100, 'LB',[], 'D',  DIMENSION,'MAX_FES', FES, 'boundConstraint', 1);     	% Simple Sphere Function

%%
for fun_index=1:numOfFun
    func_num=funToRun(fun_index);
    fun=funs(func_num);
    fun.NP = NP;
    fun.objfun = @(x) funValue(x, fun.fname);  % the handle of the objective function
    
    bestval = [];
    bestval1=[];
    bestval2=[];
    filename_res = sprintf('result/resultf%02d.txt',func_num);
    filename_time = sprintf('result/timef%02d.txt',func_num);
    
    fid_res=fopen(filename_res,'wt');
    fid_time=fopen(filename_time,'wt');
         
    for runindex=1:runs
        tic;
        seed = runindex;
        rand('state',seed);
        randn('state',seed);
        
        filename_tra = sprintf('trace/tracef%02d_%02d.txt', func_num, runindex);
        filename_group = sprintf('trace/groupf%02d_%02d.txt',func_num, runindex);
        filename_fes = sprintf('trace/fesf%02d_%02d.txt',func_num,runindex);
        
        fid_para(1)=fopen(filename_tra,'wt');
        fid_para(2)=fopen(filename_group,'wt');
        fid_para(3)=fopen(filename_fes,'wt');
        fprintf('=====================RUNS= %d=======================\n',runindex);
        initial_flag = 0;
        
        val = CCVIL(fun, algorithm,outputInteval);

        bestval_cur=min(val.bfv);
        bestval = [bestval bestval_cur];
        
        bestval_cur1=min(val.bfv1);
        bestval1 = [bestval1 bestval_cur1];
        
        bestval_cur2=min(val.bfv2);
        bestval2 = [bestval2 bestval_cur2];
        RunningTime = toc
        
        fprintf(fid_para(1),'%g\n',val.bfv);
        fprintf(fid_para(2),'%g\n',val.group);
        fprintf(fid_para(3),'%d\n',val.fes);
        
        for i=1:length(fid_para)
            fclose(fid_para(i));
        end
        fprintf(fid_res,'%g\n',bestval_cur);                
        fprintf(fid_time,'%g\n',RunningTime);
    end
    
    %% Draw the convergence gragh
    fig = figure
    semilogy(val.fes, val.bfv, 'b-');    
    xlim([min(val.fes) max(val.fes)]);
    ylim([min(val.bfv) max(val.bfv)]);
    grid on; box on;
    xlabel('FEs'); ylabel('the best fitness in current population fitness value');
    title(sprintf('Function %d (optimized by %s)', fun.fname-48, algorithm.name));
    svName = sprintf('f%02d.fig',fun.fname-48);
    saveas(fig,svName);

    fclose(fid_res);
    fclose(fid_time);
    
    %% compute the order statistics by sort
    order_bestval1 = sort(bestval1,'ascend');
    order_bestval2 = sort(bestval2,'ascend');
    order_bestval = sort(bestval,'ascend');
    
    %% store Best value of several independent runs
    filename = sprintf('result/result_f%02d.txt', func_num);
    fid = fopen(filename, 'wt');
    %
    fprintf(fid, '%6.2e\n', order_bestval1(1));
    fprintf(fid, '%6.2e\n', order_bestval1(floor(runs/2)+1));
    fprintf(fid, '%6.2e\n', order_bestval1(runs));
    fprintf(fid, '%6.2e\n', mean(bestval1));
    fprintf(fid, '%6.2e\n', std(bestval1));
    fprintf(fid, '\n');
    fprintf(fid, '%6.2e\n', order_bestval2(1));
    fprintf(fid, '%6.2e\n', order_bestval2(floor(runs/2)+1));
    fprintf(fid, '%6.2e\n', order_bestval2(runs));
    fprintf(fid, '%6.2e\n', mean(bestval2));
    fprintf(fid, '%6.2e\n', std(bestval2));
    fprintf(fid, '\n');
    fprintf(fid, '%6.2e\n', order_bestval(1));
    fprintf(fid, '%6.2e\n', order_bestval(floor(runs/2)+1));
    fprintf(fid, '%6.2e\n', order_bestval(runs));
    fprintf(fid, '%6.2e\n', mean(bestval));
    fprintf(fid, '%6.2e\n', std(bestval));
    fclose(fid);
end