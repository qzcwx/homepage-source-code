function  [same,groupi,groupj]=sameGroup(i,j,group)
% Judge whether ith and jth subcomponent are in the same group
% If yes, same = true; else, same = false;
groupi = 0;
groupj = 0;
same = false;
% search group index for i
disp('BEGIN LOOP');
% pause;
for t = 1:length(group)   
%     t 
    matI = repmat(i',1,size(group{t},2));
    matG = repmat(group{t},size(i',1),1);
%     s = sum(sum(matI==matG))
    if sum(sum(matI==matG)) == length(i)
        groupi = t;
        break;
    end
end
disp('END..1..');
% pause;

% search group index for i
for t = 1:length(group)
%     t
    matJ = repmat(j',1,size(group{t},2));
    matG = repmat(group{t},size(j',1),1);
%     s = sum(sum(matJ==matG))
    if sum(sum(matJ == matG)) == length(j)
        groupj = t;
        break;
    end
end
disp('END..2..');
% pause;
% groupi
% groupj
if groupi==0 || groupj == 0
    disp('ERROR: i or j index not found in Funtion sameGroup');
    pause;
elseif groupi==groupj
    same = true;
end