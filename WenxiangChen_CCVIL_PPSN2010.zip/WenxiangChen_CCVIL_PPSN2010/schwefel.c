// schewefel.c
// rewrite the iteration part of schwefel function to further speed up execution
// Author: Wenxiang Chen 2010-3-29 16:20:31
// Emaill: chenwx@mail.ustc.edu.cn

#include "mex.h"
void mexFunction(int nlhs, mxArray *plhs[], 
        int nrhs, const mxArray *prhs[]){
	
	double *output,*x,fit,totalFit;
	int M,N,i,j,k,index;
	// Get the input X
	x = mxGetPr(prhs[0]);
	M = mxGetM(prhs[0]);	
	N = mxGetN(prhs[0]);

	// Preparation for output parameters
	plhs[0] = mxCreateDoubleMatrix(M,1,mxREAL);
	output = mxGetPr(plhs[0]);
    // 	Map to data[j*M+i]
	for(i=0;i<M;i++)
	{	// For each individual in the population
		totalFit = 0;
		for(k=0; k<N; k++)
		{	
			fit = 0;            
            for (j=0;j<=k;j++)
            {    
                fit = fit + x[j*M+i];
            }
			totalFit = totalFit + fit*fit;
		}
		output[i] = totalFit;
	}
}
